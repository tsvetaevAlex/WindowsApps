// VisualLoggerForm.Designer.cs
